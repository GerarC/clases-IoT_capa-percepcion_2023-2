#include <Arduino.h>

/* ---- Pines I/O ---- */
const int redPin = 19;     // Red RGB pin -> P19 (GPIO19)
const int greenPin = 18;   // Green RGB pin -> P18 (GPIO18)
const int bluePin = 5;     // Blue RGB pin -> P5 (GPIO5)
const int buttonPin = 15;  // Button pin -> P17 (GPIO17)

// Constantes
const int DEBOUNCE_TIME = 50;
const int T_TIME = 2000;

// Eventos
volatile int BUTTON_EVENT = LOW;
volatile int EVENT_DELAY = LOW;
volatile int EVENT_T = LOW;

// Variables de estado
int buttonState;
bool color_red = true; 

// Timers
hw_timer_t *delay_timer = NULL;        // H/W timer (timer 0)
hw_timer_t *period_timer = NULL;       // H/W timer (timer 1) 

void button_handler() {
  BUTTON_EVENT = HIGH;
}

void ARDUINO_ISR_ATTR delay_handler() {
  EVENT_DELAY = HIGH;
}

void ARDUINO_ISR_ATTR period_handler() {
  EVENT_T = HIGH;
}

/* ---- Setup ---- */
void setup() {
  // Inicializacion de pines
  pinMode(redPin, OUTPUT);
  pinMode(bluePin, OUTPUT);
  pinMode(greenPin, OUTPUT);
  pinMode(buttonPin, INPUT);
  digitalWrite(redPin, LOW);
  digitalWrite(bluePin, LOW);
  digitalWrite(greenPin, LOW);
  // Interrupciones externas
  attachInterrupt(digitalPinToInterrupt(buttonPin), button_handler, RISING);
  // Timers
  // delay
  delay_timer = timerBegin(0, 80, true);
  timerAttachInterrupt(delay_timer, &delay_handler, true);
  timerAlarmWrite(delay_timer, DEBOUNCE_TIME*1000, true);
  timerAlarmEnable(delay_timer);
  // period (T)
  period_timer = timerBegin(1, 80, true);
  timerAttachInterrupt(period_timer, &period_handler, true);
  timerAlarmWrite(period_timer, T_TIME*1000, true);
  timerAlarmEnable(period_timer);
  // Serial.begin(9600);
}

/* ---- Loop ---- */
void loop() {
  if (BUTTON_EVENT == HIGH) {
    timerRestart(delay_timer);
    if (EVENT_DELAY == HIGH) {
      // Serial.println("Boton presionado");      
      EVENT_DELAY = LOW;
      color_red = !color_red;
    }
    BUTTON_EVENT = LOW;
  }
  /*
  if (EVENT_DELAY == HIGH) {    
    EVENT_DELAY = LOW;
  }
  */
  if (EVENT_T == HIGH) {
    if (color_red == true) { 
      digitalWrite(redPin, HIGH);  
      digitalWrite(greenPin, LOW); 
    }
    else {
      digitalWrite(redPin, LOW);  
      digitalWrite(greenPin, HIGH); 
    }
    delay(100);
    digitalWrite(redPin, LOW);  
    digitalWrite(greenPin, LOW); 
    EVENT_T = LOW;
  }
}