#include <Arduino.h>

/* ---- Pines I/O ---- */
const int redPin = 19;     // Red RGB pin -> P19 (GPIO19)
const int greenPin = 18;   // Green RGB pin -> P18 (GPIO18)
const int bluePin = 5;     // Blue RGB pin -> P5 (GPIO5)
const int buttonPin = 15;  // Button pin -> P17 (GPIO17)

// Constantes
const int DEBOUNCE_TIME = 50;
const int T_TIME = 2000;
const int ON_TIME = 100;

// Variables de estado
int buttonState = LOW;
int last_buttonState = LOW; 
bool color_red = true; 

// Hilos
TaskHandle_t hilo1;

//Task1code: blinks an LED every 1000 ms
void cambiarColor( void * pvParameters ){
  for(;;){
    buttonState = digitalRead(buttonPin);
    delay(DEBOUNCE_TIME); // Delay
    last_buttonState = buttonState;
    buttonState = digitalRead(buttonPin);
    if (buttonState == last_buttonState) {
      // Valor estable
      if (buttonState == HIGH) {
        // Serial.println("Cambio");
        color_red = !color_red;
      }
    }   
  } 
}

void setup() {
  // Inicializacion de pines
  pinMode(redPin, OUTPUT);
  pinMode(bluePin, OUTPUT);
  pinMode(greenPin, OUTPUT);
  pinMode(buttonPin, INPUT);
  digitalWrite(redPin, LOW);
  digitalWrite(bluePin, LOW);
  digitalWrite(greenPin, LOW);
  // Serial
  Serial.begin(9600);

  // Hilos
  xTaskCreatePinnedToCore(
                    cambiarColor,   /* Task function. */
                    "cambiarColor",     /* name of task. */
                    10000,       /* Stack size of task */
                    NULL,        /* parameter of the task */
                    1,           /* priority of the task */
                    &hilo1,      /* Task handle to keep track of created task */
                    0);          /* pin task to core 0 */                  
  delay(500); 
}

void loop() {
  // En el hilo principal se realiza el parpadeo
  if(color_red == true) {
    digitalWrite(redPin, HIGH);
    digitalWrite(greenPin, LOW);
  }
  else {
    digitalWrite(redPin, LOW);
    digitalWrite(greenPin, HIGH);
  }
  delay(ON_TIME);
  digitalWrite(redPin, LOW);
  digitalWrite(greenPin, LOW);
  delay(T_TIME - ON_TIME);
}
