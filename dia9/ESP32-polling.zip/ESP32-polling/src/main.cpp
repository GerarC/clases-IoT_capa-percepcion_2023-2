#include <Arduino.h>

/* ---- Pines I/O ---- */
const int redPin = 19;     // Red RGB pin -> P19 (GPIO19)
const int greenPin = 18;   // Green RGB pin -> P18 (GPIO18)
const int bluePin = 5;     // Blue RGB pin -> P5 (GPIO5)
const int buttonPin = 15;  // Button pin -> P17 (GPIO17)

int buttonState;

/* ---- Setup ---- */
void setup() {
  pinMode(redPin, OUTPUT);
  pinMode(bluePin, OUTPUT);
  pinMode(greenPin, OUTPUT);
  pinMode(buttonPin, INPUT);
  digitalWrite(redPin, LOW);
  digitalWrite(bluePin, LOW);
  digitalWrite(greenPin, LOW);
  // Serial.begin(9600);
}

/* ---- Loop ---- */
void loop() {
  buttonState = digitalRead(buttonPin);
  if (buttonState == LOW) {
    // Led: RED
    // Serial.println(buttonState);
    digitalWrite(redPin, HIGH);  
    digitalWrite(greenPin, LOW); 
    digitalWrite(bluePin, LOW);
  }
  else {
    // Led: GREEN
    // Serial.println(buttonState);
    digitalWrite(redPin, LOW);  
    digitalWrite(greenPin, HIGH); 
    digitalWrite(bluePin, LOW);
  }
  delay(100);
  // Led: OFF 
  digitalWrite(redPin, LOW); 
  digitalWrite(greenPin, LOW); 
  digitalWrite(bluePin, LOW);
  delay(1900);
}