#pragma once

#include <string>

using namespace std;


// WiFi credentials
const char *SSID = "IoT";
const char *PASSWORD = "1245678h";

// ------------------------- MQTT Network ------------------------- //
const string BROKER = "192.168.43.55";

// ----------- thing-001 (self - ESP32-PIR)
// I/O config
// Lamps
#define LIGHT_PIN 2
// PIR
#define PIR_MOTION_SENSOR 5

// MQTT settings
const string ID = "thing-001";
const string CLIENT_NAME = ID + "_ESP32-PIR";

// Topics
const string TOPIC1 = ID + "/home/store/sensors/presence/pir";
const string TOPIC2 = ID + "/home/store/actuators/lamps/lamp1";

// ----------- thing-002 (ESP32-ALARM)
// No se necesita poner nada

// ----------- iot-server (control)
// No se ha implementado aun