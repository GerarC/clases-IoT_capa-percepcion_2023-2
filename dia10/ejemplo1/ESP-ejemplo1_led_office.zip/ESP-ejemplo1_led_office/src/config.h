#pragma once
#include <string>

using namespace std;

// ESP32 I/O config
const int LIGHT_PIN = 2; // GPIO2 (LED_BUILTIN) 

// WiFi credentials
const char *SSID = "IoT";
const char *PASSWORD = "1245678h";

// MQTT settings
const string ID = "thing-001";

const string BROKER = "192.168.43.55";
const string CLIENT_NAME = ID + "lamp_client";

const string TOPIC = "home/office/lamp";